<?php
include_once 'db.php';
header('Content-Type: application/json');

$sender_id = $_POST['sender_id'];
$receiver_id = $_POST['receiver_id'];
$message = trim($_POST['message']);

if (!$sender_id || !$receiver_id || !$message) {
    echo json_encode(['status' => false, 'message' => 'All fields are required!']);
    exit;
}

// Check if users are friends
$stmt = $conn->prepare("SELECT id FROM friend_requests WHERE (sender_id = ? AND receiver_id = ? OR sender_id = ? AND receiver_id = ?) AND status = 'accepted'");
$stmt->bind_param("iiii", $sender_id, $receiver_id, $receiver_id, $sender_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    echo json_encode(['status' => false, 'message' => 'Users are not friends!']);
    exit;
}

// Insert the message
$stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
$stmt->bind_param("iis", $sender_id, $receiver_id, $message);

if ($stmt->execute()) {
    echo json_encode(['status' => true, 'message' => 'Message sent!']);
} else {
    echo json_encode(['status' => false, 'message' => 'Error sending message!']);
}

$stmt->close();
$conn->close();
?>
