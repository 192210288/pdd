<?php

include_once 'db.php';  // Ensure the database connection is correct
header('Content-Type: application/json');

// Check the connection
if ($conn->connect_error) {
    echo json_encode([
        'status' => false,
        'message' => 'Connection failed: ' . $conn->connect_error
    ]);
    exit;
}

// Capture form-data and raw JSON data
$inputData = $_POST;

// If JSON data is sent
if (empty($inputData)) {
    $jsonData = json_decode(file_get_contents("php://input"), true);
    if ($jsonData) {
        $inputData = $jsonData;
    }
}

// Extract description
$description = isset($inputData['description']) ? trim($inputData['description']) : '';

// Validate input fields
if (empty($description)) {
    echo json_encode([
        'status' => false,
        'message' => 'Description is required!'
    ]);
    exit;
}

// Check if the description already exists
$stmt = $conn->prepare("SELECT id FROM groups WHERE description = ?");
$stmt->bind_param("s", $description);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo json_encode([
        'status' => false,
        'message' => 'Description already exists!'
    ]);
    $stmt->close();
    exit;
}
$stmt->close();

// Insert new description into database
$stmt = $conn->prepare("INSERT INTO groups (description) VALUES (?)");
$stmt->bind_param("s", $description);

if ($stmt->execute()) {
    $group_id = $stmt->insert_id; // Get the inserted ID

    // Fetch the newly added record
    $query = $conn->prepare("SELECT id, description FROM groups WHERE id = ?");
    $query->bind_param("i", $group_id);
    $query->execute();
    $result = $query->get_result();
    $groupData = $result->fetch_assoc();

    echo json_encode([
        'status' => true,
        'message' => 'Description added successfully!',
        'data' => $groupData // Include the inserted data
    ]);
    $query->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Error executing query: ' . $stmt->error
    ]);
}

$stmt->close();
$conn->close();

?>
