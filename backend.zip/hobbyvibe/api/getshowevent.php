<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('db.php');
header("Content-Type: application/json");

// Check if the request method is GET
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $sql = "SELECT event_name, event_image, description, event_date FROM showevent";
    $result = $conn->query($sql);

    if (!$result) {
        echo json_encode(["status" => false, "error" => "Query failed: " . $conn->error]);
        exit();
    }

    if ($result->num_rows > 0) {
        $events = [];
        while ($row = $result->fetch_assoc()) {
            $events[] = [
                "event_name" => $row['event_name'],
                "event_image" => $row['event_image'],
                "description" => $row['description'],
                "event_date" => $row['event_date'] // ✅ Include event_date
            ];
        }
        echo json_encode(["status" => true, "message" => "Events found", "data" => $events]);
    } else {
        echo json_encode(["status" => false, "message" => "No events found"]);
    }

    $conn->close();
}
?>
