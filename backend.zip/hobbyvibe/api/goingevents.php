<?php
include('db.php'); // Ensure your database connection file is correct
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Allow API access from different sources

// Check database connection
if ($conn->connect_error) {
    echo json_encode([
        'status' => false,
        'message' => 'Database connection failed: ' . $conn->connect_error
    ], JSON_PRETTY_PRINT);
    exit;
}

// Ensure request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method. Use POST.'
    ], JSON_PRETTY_PRINT);
    exit;
}

// Extract form data from $_POST (No JSON processing, only form-data)
$event_name = isset($_POST['event_name']) ? trim($_POST['event_name']) : '';
$venue = isset($_POST['venue']) ? trim($_POST['venue']) : '';
$date = isset($_POST['date']) ? trim($_POST['date']) : '';
$time = isset($_POST['time']) ? trim($_POST['time']) : '';
$is_paid = isset($_POST['is_paid']) ? trim($_POST['is_paid']) : '';
$ticket_price = isset($_POST['ticket_price']) ? floatval($_POST['ticket_price']) : 0;

// Validate required fields
if (empty($event_name) || empty($venue) || empty($date) || empty($time) || empty($is_paid)) {
    echo json_encode([
        'status' => false,
        'message' => 'All fields are required!'
    ], JSON_PRETTY_PRINT);
    exit;
}

// Insert event into the database using a prepared statement
$stmt = $conn->prepare("INSERT INTO events (event_name, venue, date, time, is_paid, ticket_price) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssd", $event_name, $venue, $date, $time, $is_paid, $ticket_price);

if ($stmt->execute()) {
    $event_id = $stmt->insert_id;

    // Fetch the newly inserted event
    $result = $conn->query("SELECT id, event_name, venue, date, time, is_paid, ticket_price FROM events WHERE id = $event_id");

    if ($result && $event = $result->fetch_assoc()) {
        // Explicitly set JSON encoding options for proper formatting
        echo json_encode([
            "status" => true,  // ✅ Success
            "message" => "Event added successfully.",
            "data" => $event
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode([
            "status" => false, // ❌ Error fetching data
            "message" => "Error fetching event details."
        ], JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode([
        "status" => false,
        "message" => "Error: " . $stmt->error
    ], JSON_PRETTY_PRINT);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
