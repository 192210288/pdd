<?php

include_once 'db.php'; // Ensure the database connection is correct
header('Content-Type: application/json');

// Capture input from form-data or raw JSON
$inputData = json_decode(file_get_contents("php://input"), true) ?? $_POST ?? [];

// Ensure field names are correct
$correctedData = [
    'event_name' => $inputData['event_name'] ?? '',
    'event_date' => $inputData['event_date'] ?? '',
    'event_description' => $inputData['event_description'] ?? '',
    'sponsor' => $inputData['sponsor'] ?? '',
    'venue' => $inputData['venue'] ?? '',
];

extract($correctedData);

// Validate input fields
if (empty($event_name) || empty($event_date) || empty($event_description) || empty($sponsor) || empty($venue)) {
    echo json_encode([
        'status' => false,
        'message' => 'All fields are required!',
        'missing_fields' => array_keys(array_filter($correctedData, fn($value) => empty($value)))
    ]);
    exit;
}

// Check if the event exists in the database
$stmt = $conn->prepare("SELECT id FROM eventcreation WHERE event_name = ?");
$stmt->bind_param("s", $event_name);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $event = $result->fetch_assoc();

    echo json_encode([
        'status' => true,
        'message' => 'Event found successfully!',
        'event' => [
            'id' => $event['id'],
            'event_name' => $event_name,
            'event_date' => $event_date,
            'event_description' => $event_description,
            'sponsor' => $sponsor,
            'venue' => $venue
        ]
    ]);
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Event not found!'
    ]);
}

$stmt->close();
$conn->close();

?>
