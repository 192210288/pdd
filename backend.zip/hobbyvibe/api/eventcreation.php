<?php
include('db.php');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check for required fields
    if (isset($_POST['event_name']) && isset($_POST['event_description']) && isset($_POST['sponsor']) && isset($_POST['venue'])) {
        $event_name = $_POST['event_name'];
        $event_description = $_POST['event_description'];
        $sponsor = $_POST['sponsor'];
        $venue = $_POST['venue'];

        // Insert data into the database
        $sql = "INSERT INTO creation (event_name, event_description, sponsor, venue) VALUES ('$event_name', '$event_description', '$sponsor', '$venue')";
        
        if ($conn->query($sql)) {
            // Fetch all records from the creation table
            $result = $conn->query("SELECT id, event_name, event_description, sponsor, venue FROM creation WHERE 1");

            if ($result && $result->num_rows > 0) {
                $events = [];
                while ($row = $result->fetch_assoc()) {
                    $events[] = $row;
                }
                echo json_encode(["message" => "Event added successfully.", "data" => $events]);
            } else {
                echo json_encode(["message" => "No data found."]);
            }
        } else {
            echo json_encode(["message" => "Error: " . $conn->error]);
        }
    } else {
        echo json_encode(["message" => "Invalid input or missing required fields."]);
    }
}
?>