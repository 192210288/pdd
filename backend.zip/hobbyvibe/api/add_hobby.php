<?php
include('db.php');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if hobby name is provided
    if (isset($_POST['hobby_name'])) {
        
        $hobby_name = $_POST['hobby_name'];

        // Insert hobby into database
        $sql = "INSERT INTO hobbies (hobby_name) VALUES ('$hobby_name')";

        if ($conn->query($sql)) {
            $hobby_id = $conn->insert_id;

            // Fetch the newly inserted hobby details
            $result = $conn->query("SELECT id, hobby_name FROM hobbies WHERE id = $hobby_id");

            if ($result && $hobby = $result->fetch_assoc()) {
                echo json_encode(["message" => "Hobby added successfully.", "data" => $hobby]);
            } else {
                echo json_encode(["message" => "Error fetching hobby details."]);
            }
        } else {
            echo json_encode(["message" => "Error: " . $conn->error]);
        }
    } else {
        echo json_encode(["message" => "Hobby name is required."]);
    }
}
?>
