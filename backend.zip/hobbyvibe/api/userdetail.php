<?php
include('db.php');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if required fields are provided
    if (isset($_POST['name'], $_POST['email'], $_POST['phone'])) {
        
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];

        // Insert user details into database
        $sql = "INSERT INTO memeber (name, email, phone) VALUES ('$name', '$email', '$phone')";

        if ($conn->query($sql)) {
            $user_id = $conn->insert_id;

            // Fetch the newly inserted user details
            $result = $conn->query("SELECT id, name, email, phone FROM memeber WHERE id = $user_id");

            if ($result && $user = $result->fetch_assoc()) {
                echo json_encode(["message" => "User added successfully.", "data" => $user]);
            } else {
                echo json_encode(["message" => "Error fetching user details."]);
            }
        } else {
            echo json_encode(["message" => "Error: " . $conn->error]);
        }
    } else {
        echo json_encode(["message" => "Name, email, and phone are required."]);
    }
}
?>