<?php
include_once 'db.php';
header('Content-Type: application/json');

$sender_id = $_POST['sender_id'];
$receiver_id = $_POST['receiver_id'];

if (!$sender_id || !$receiver_id) {
    echo json_encode(['status' => false, 'message' => 'Both sender and receiver are required!']);
    exit;
}

// Check if request already exists
$stmt = $conn->prepare("SELECT id FROM friend_request WHERE sender_id = ? AND receiver_id = ? AND status = 'pending'");
$stmt->bind_param("ii", $sender_id, $receiver_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode(['status' => false, 'message' => 'Friend request already sent!']);
    exit;
}

$stmt = $conn->prepare("INSERT INTO friend_requests (sender_id, receiver_id) VALUES (?, ?)");
$stmt->bind_param("ii", $sender_id, $receiver_id);

if ($stmt->execute()) {
    echo json_encode(['status' => true, 'message' => 'Friend request sent!']);
} else {
    echo json_encode(['status' => false, 'message' => 'Error sending request!']);
}

$stmt->close();
$conn->close();
?>
