<?php
include_once 'db.php';
header('Content-Type: application/json');

$request_id = $_POST['request_id'];
$status = $_POST['status']; // 'accepted' or 'rejected'

if (!$request_id || !in_array($status, ['accepted', 'rejected'])) {
    echo json_encode(['status' => false, 'message' => 'Invalid request!']);
    exit;
}

$stmt = $conn->prepare("UPDATE friend_requests SET status = ? WHERE id = ?");
$stmt->bind_param("si", $status, $request_id);

if ($stmt->execute()) {
    echo json_encode(['status' => true, 'message' => 'Friend request updated!']);
} else {
    echo json_encode(['status' => false, 'message' => 'Error updating request!']);
}

$stmt->close();
$conn->close();
?>
