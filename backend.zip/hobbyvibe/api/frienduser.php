<?php
include_once 'db.php';
header('Content-Type: application/json');

$name = $_POST['name'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

if (!$name || !$email || !$password) {
    echo json_encode(['status' => false, 'message' => 'All fields are required!']);
    exit;
}

$stmt = $conn->prepare("INSERT INTO user (name, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $password);

if ($stmt->execute()) {
    echo json_encode(['status' => true, 'message' => 'User registered successfully!']);
} else {
    echo json_encode(['status' => false, 'message' => 'Registration failed!']);
}

$stmt->close();
$conn->close();
?>
