<?php
include('db.php');
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$target_dir = __DIR__ . "/uploads/"; // Ensure absolute path
$image_new_name = uniqid() . "." . pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
$target_file = $target_dir . $image_new_name;

if (!is_writable($target_dir)) {
    echo json_encode(["status" => "error", "message" => "Uploads directory is not writable."]);
    exit;
}

if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
    echo json_encode(["status" => "success", "message" => "Event image uploaded!", "image_url" => $target_file]);
} else {
    echo json_encode(["status" => "error", "message" => "File upload failed. Check permissions."]);
}

    // Handle the uploaded image
    $image_name = basename($_FILES["event_image"]["name"]);
    $image_tmp_name = $_FILES["event_image"]["tmp_name"];
    $image_path = $upload_dir . $image_name;

    // Validate image type (only JPG & PNG allowed)
    $image_file_type = strtolower(pathinfo($image_path, PATHINFO_EXTENSION));
    if ($image_file_type != "jpg" && $image_file_type != "png") {
        echo json_encode(["message" => "Only JPG and PNG images are allowed."]);
        exit();
    }

    // Move uploaded file to the server directory
    if (!move_uploaded_file($image_tmp_name, $image_path)) {
        echo json_encode(["message" => "Failed to upload event image."]);
        exit();
    }

    // Insert event details into the database using prepared statement to prevent SQL injection
    $sql = "INSERT INTO eventimage (event_image, event_description) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $image_path, $event_description);

    if ($stmt->execute()) {
        echo json_encode([
            "message" => "Event added successfully.",
            "data" => [
                "event_image" => $image_path,
                "event_description" => $event_description
            ]
        ]);
    } else {
        echo json_encode(["message" => "Database error: " . $stmt->error]);
    }

    $stmt->close();
} else {
    echo json_encode(["message" => "Invalid request method."]);
}
?>
