<?php

include_once 'db.php';  // Ensure the database connection is correct
header('Content-Type: application/json');

// Check the database connection
if ($conn->connect_error) {
    echo json_encode([
        'status' => false,
        'message' => 'Connection failed: ' . $conn->connect_error
    ]);
    exit;
}

// Capture form-data
$review_text = isset($_POST['review']) ? trim($_POST['review']) : '';

// Validate input field
if (empty($review_text)) {
    echo json_encode([
        'status' => false,
        'message' => 'Review text is required!'
    ]);
    exit;
}

// Check if the review already exists
$stmt = $conn->prepare("SELECT id FROM reviews WHERE review_text = ?");
$stmt->bind_param("s", $review_text);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo json_encode([
        'status' => false,
        'message' => 'Duplicate review is not allowed!'
    ]);
    $stmt->close();
    exit;
}
$stmt->close();

// Insert new review into the database
$stmt = $conn->prepare("INSERT INTO reviews (review_text) VALUES (?)");
$stmt->bind_param("s", $review_text);

if ($stmt->execute()) {
    $review_id = $stmt->insert_id; // Get the inserted review ID

    // Fetch the newly added record
    $query = $conn->prepare("SELECT id, review_text FROM reviews WHERE id = ?");
    $query->bind_param("i", $review_id);
    $query->execute();
    $result = $query->get_result();
    $reviewData = $result->fetch_assoc();

    echo json_encode([
        'status' => true,
        'message' => 'Review added successfully!',
        'data' => $reviewData // Include the inserted data
    ]);
    $query->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Error executing query: ' . $stmt->error
    ]);
}

$stmt->close();
$conn->close();

?>
