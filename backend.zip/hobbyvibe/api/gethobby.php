<?php
include('db.php');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if hobby name is provided
    if (isset($_POST['hobby_name'])) {
        
        $hobby_name = $_POST['hobby_name'];

        // Search for the hobby in the database
        $sql = "SELECT id, hobby_name FROM hobbies WHERE hobby_name = '$hobby_name' LIMIT 1";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $hobby = $result->fetch_assoc();
            echo json_encode(["message" => "Hobby found successfully.", "data" => $hobby]);
        } else {
            echo json_encode(["message" => "Hobby not found."]);
        }
    } else {
        echo json_encode(["message" => "Hobby name is required."]);
    }
}
?>
