<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('db.php');
header("Content-Type: application/json");

// Check if the request method is GET
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $sql = "SELECT `id`, `event_name`, `venue`, `date`, `time`, `is_paid`, `ticket_price` FROM `events`";
    $result = $conn->query($sql);

    if (!$result) {
        echo json_encode(["status" => false, "error" => "Query failed: " . $conn->error]);
        exit();
    }

    if ($result->num_rows > 0) {
        $events = [];
        while ($row = $result->fetch_assoc()) {
            $events[] = $row;
        }
        echo json_encode(["status" => true, "data" => $events]);
    } else {
        echo json_encode(["status" => false, "message" => "No events found"]);
    }

    $conn->close();
}
?>
