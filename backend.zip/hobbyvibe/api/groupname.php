<?php

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once 'db.php';  
header('Content-Type: application/json');

// Check the database connection
if ($conn->connect_error) {
    die(json_encode([
        'status' => false,
        'message' => 'Database connection failed: ' . $conn->connect_error
    ]));
}

// Capture JSON or Form-data input
$inputData = json_decode(file_get_contents("php://input"), true) ?? $_POST;

// Extract group name
$group_name = isset($inputData['group_name']) ? trim($inputData['group_name']) : '';

// Validate input field
if (empty($group_name)) {
    die(json_encode([
        'status' => false,
        'message' => 'Group name is required!'
    ]));
}

// Check if the group name already exists
$stmt = $conn->prepare("SELECT id FROM groupname WHERE group_name = ? LIMIT 1");
$stmt->bind_param("s", $group_name);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->close();
    die(json_encode([
        'status' => false,
        'message' => 'Group name is already taken!'
    ]));
}
$stmt->close();

// Insert new group into database
$stmt = $conn->prepare("INSERT INTO groupname (group_name) VALUES (?)");
$stmt->bind_param("s", $group_name);

if ($stmt->execute()) {
    $group_id = $stmt->insert_id; // Get the inserted ID

    // Fetch the newly added record
    $query = $conn->prepare("SELECT id, group_name FROM groupname WHERE id = ?");
    $query->bind_param("i", $group_id);
    $query->execute();
    $result = $query->get_result();
    $groupData = $result->fetch_assoc();

    echo json_encode([
        'status' => true,
        'message' => 'Group registration successful!',
        'data' => $groupData
    ]);
    $query->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Database error: ' . $stmt->error
    ]);
}

$stmt->close();
$conn->close();

?>
