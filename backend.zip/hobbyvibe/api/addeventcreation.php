<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once 'db.php';  // Ensure this file contains correct DB connection details
header('Content-Type: application/json');

// Check database connection
if ($conn->connect_error) {
    echo json_encode(['status' => false, 'message' => 'Connection failed: ' . $conn->connect_error]);
    exit;
}

// Capture form-data and raw JSON data
$inputData = json_decode(file_get_contents("php://input"), true) ?? $_POST;

// Validate input fields
if (
    empty($inputData['event_name']) || empty($inputData['event_date']) ||
    empty($inputData['event_description']) || empty($inputData['sponsor']) || empty($inputData['venue'])
) {
    echo json_encode(['status' => false, 'message' => 'All fields are required!']);
    exit;
}

// Extract form values
$eventName = trim($inputData['event_name']);
$eventDate = trim($inputData['event_date']);
$eventDescription = trim($inputData['event_description']);
$sponsor = trim($inputData['sponsor']);
$venue = trim($inputData['venue']);

// Check if event already exists
$stmt = $conn->prepare("SELECT id FROM eventcreation WHERE event_name = ?");
if (!$stmt) {
    die(json_encode(['status' => false, 'message' => 'SQL prepare error: ' . $conn->error]));
}
$stmt->bind_param("s", $eventName);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo json_encode(['status' => false, 'message' => 'Event name is already registered!']);
    $stmt->close();
    exit;
}
$stmt->close();

// Insert new event
$stmt = $conn->prepare("INSERT INTO eventcreation (event_name, event_date, event_description, sponsor, venue) VALUES (?, ?, ?, ?, ?)");
if (!$stmt) {
    die(json_encode(['status' => false, 'message' => 'SQL prepare error: ' . $conn->error]));
}
$stmt->bind_param("sssss", $eventName, $eventDate, $eventDescription, $sponsor, $venue);
if (!$stmt->execute()) {
    die(json_encode(['status' => false, 'message' => 'Database error: ' . $stmt->error]));
}

// Get last inserted event ID
$last_id = $conn->insert_id;

// Fetch inserted event data
$stmt = $conn->prepare("SELECT id, event_name, event_date, event_description, sponsor, venue FROM eventcreation WHERE id = ?");
if (!$stmt) {
    die(json_encode(['status' => false, 'message' => 'SQL prepare error: ' . $conn->error]));
}
$stmt->bind_param("i", $last_id);
$stmt->execute();
$result = $stmt->get_result();
$eventData = $result->fetch_assoc();

// ✅ Fixed JSON response (added missing comma)
echo json_encode([
    'status' => true,
    'message' => 'Event registration successful!',
    'received_data' => $inputData // ✅ Comma added here
]);

$stmt->close();
$conn->close();

?>
