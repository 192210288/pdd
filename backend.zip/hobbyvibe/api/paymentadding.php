<?php

include_once 'db.php';  // Ensure the database connection is correct
header('Content-Type: application/json');

// Check the connection
if ($conn->connect_error) {
    echo json_encode([
        'status' => false,
        'message' => 'Connection failed: ' . $conn->connect_error
    ]);
    exit;
}

// Check if data was received via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get the form data
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';

    // Validate the input data
    if (empty($name) || empty($email) || empty($phone)) {
        echo json_encode([
            'status' => false,
            'message' => 'All fields are required!',
            'received_data' => $_POST  // Include received data for debugging
        ]);
        exit;
    }

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode([
            'status' => false,
            'message' => 'Invalid email format!'
        ]);
        exit;
    }

    // Validate phone number (basic check for 10-digit number)
    if (!preg_match("/^[0-9]{10}$/", $phone)) {
        echo json_encode([
            'status' => false,
            'message' => 'Invalid phone number format!'
        ]);
        exit;
    }

    // Check if the email already exists in the database
    try {
        $emailCheck = $conn->prepare("SELECT id FROM payment WHERE email = ?");
        $emailCheck->bind_param("s", $email);
        $emailCheck->execute();
        $emailResult = $emailCheck->get_result();
        if ($emailResult->num_rows > 0) {
            echo json_encode([
                'status' => false,
                'message' => 'Email is already registered!',
                'received_data' => $_POST
            ]);
            $emailCheck->close();
            exit;
        }
        $emailCheck->close();
    } catch (Exception $e) {
        echo json_encode([
            'status' => false,
            'message' => 'Error checking email: ' . $e->getMessage()
        ]);
        exit;
    }

    // Prepare SQL to insert the data into the database
    try {
        $stmt = $conn->prepare("INSERT INTO payment (name, email, phone) VALUES (?, ?, ?)");
        
        if ($stmt === false) {
            echo json_encode([
                'status' => false,
                'message' => 'Error preparing the statement: ' . $conn->error
            ]);
            exit;
        }

        $stmt->bind_param("sss", $name, $email, $phone);

        if ($stmt->execute()) {
            // Fetch last inserted ID
            $insertedId = $stmt->insert_id;
            
            echo json_encode([
                'status' => true,
                'message' => 'Signup successful!',
                'inserted_data' => [
                    'id' => $insertedId,
                    'name' => $name,
                    'email' => $email,
                    'phone' => $phone
                ]
            ]);
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'Error executing query: ' . $stmt->error
            ]);
        }

        $stmt->close();
    } catch (Exception $e) {
        echo json_encode([
            'status' => false,
            'message' => 'Error during signup: ' . $e->getMessage()
        ]);
    }

    $conn->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method!'
    ]);
}

?>
