<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('db.php');
header("Content-Type: application/json");

// Check if the request method is GET
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // ✅ Updated SQL Query (Removed 'keyword' column)
    $sql = "SELECT `id`, `group_name` FROM `groupname`";  
    $result = $conn->query($sql);

    if (!$result) {
        echo json_encode(["status" => false, "error" => "Query failed: " . $conn->error]);
        exit();
    }

    if ($result->num_rows > 0) {
        $groups = [];
        while ($row = $result->fetch_assoc()) {
            $groups[] = $row;
        }
        echo json_encode(["status" => true,"message" => "group found" ,"data" => $groups]);
    } else {
        echo json_encode(["status" => false, "message" => "No groups found"]);
    }

    $conn->close();
}
?>
