<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('db.php');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $event_name = $_POST['event_name'];
    $description = $_POST['description'];
    $event_date = $_POST['event_date']; // New field

    // Validate input
    if (empty($event_name) || empty($description) || empty($event_date)) {
        echo "Event name, description, and date must be filled out!";
        exit;
    }

    // Handle image upload
    $event_image = NULL; // Default to NULL if no image is uploaded
    if (isset($_FILES['event_image']) && $_FILES['event_image']['error'] === 0) {
        $image = $_FILES['event_image']['name'];
        $image_tmp = $_FILES['event_image']['tmp_name'];
        $image_size = $_FILES['event_image']['size'];
        $file_extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($file_extension, $allowed_extensions) && $image_size < 2000000) {
            // Generate a unique image name and move it to the 'uploads' folder
            $event_image = uniqid('', true) . '.' . $file_extension;
            $image_destination = 'uploads/' . $event_image;
            move_uploaded_file($image_tmp, $image_destination);
        } else {
            echo "Invalid file type or file is too large.";
            exit;
        }
    }

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare the SQL insert query
    $sql = "INSERT INTO `showevent` (`event_name`, `event_image`, `description`, `event_date`) VALUES (?, ?, ?, ?)";

    // Prepare and bind the statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $event_name, $event_image, $description, $event_date);

    // Execute the query
    if ($stmt->execute()) {
        echo "Event inserted successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
