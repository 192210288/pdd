<?php

include_once 'db.php';  // Ensure the database connection is correct
header('Content-Type: application/json');

// Capture input from form-data or raw JSON
$inputData = [];

// If form-data (x-www-form-urlencoded or form-data)
if (!empty($_POST)) {
    $inputData = $_POST;
}

// If JSON data is sent
$jsonInput = json_decode(file_get_contents("php://input"), true);
if (!empty($jsonInput)) {
    $inputData = $jsonInput;
}

// Extract form values
$email = isset($inputData['email']) ? trim($inputData['email']) : '';
$password = isset($inputData['password']) ? trim($inputData['password']) : '';

// Validate input fields
if (empty($email) || empty($password)) {
    echo json_encode([
        'status' => false,
        'message' => 'Email and password are required!',
        'received_data' => $inputData // Debugging output
    ]);
    exit;
}

// Fetch user from the database
$stmt = $conn->prepare("SELECT id, name, email, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    $user = $result->fetch_assoc();

    // Verify password
    if (password_verify($password, $user['password'])) {
        echo json_encode([
            'status' => true,
            'message' => 'Login successful!',
            'user' => [
                'id' => $user['id'],
                'name' => $user['name'],
                'email' => $user['email']
            ]
        ]);
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Incorrect password!'
        ]);
    }
} else {
    echo json_encode([
        'status' => false,
        'message' => 'User not found!'
    ]);
}

$stmt->close();
$conn->close();

?>
