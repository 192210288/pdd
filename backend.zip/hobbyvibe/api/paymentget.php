<?php

include_once 'db.php';  // Ensure the database connection is correct
header('Content-Type: application/json');

// Capture input from form-data or raw JSON
$inputData = [];

// If form-data (x-www-form-urlencoded or form-data)
if (!empty($_POST)) {
    $inputData = $_POST;
}

// If JSON data is sent
$jsonInput = json_decode(file_get_contents("php://input"), true);
if (!empty($jsonInput)) {
    $inputData = $jsonInput;
}

// Extract form values
$email = isset($inputData['email']) ? trim($inputData['email']) : '';
$phone = isset($inputData['phone']) ? trim($inputData['phone']) : '';

// Validate input fields
if (empty($email) || empty($phone)) {
    echo json_encode([
        'status' => false,
        'message' => 'Email and phone number are required!',
        'received_data' => $inputData // Debugging output
    ]);
    exit;
}

// Fetch user from the database
$stmt = $conn->prepare("SELECT id, name, email, phone FROM payment WHERE email = ? AND phone = ?");
$stmt->bind_param("ss", $email, $phone);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    $user = $result->fetch_assoc();

    echo json_encode([
        'status' => true,
        'message' => 'Login successful!',
        'user' => [
            'id' => $user['id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'phone' => $user['phone']
        ]
    ]);
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid email or phone number!'
    ]);
}

$stmt->close();
$conn->close();

?>
